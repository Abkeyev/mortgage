window.env = {
  OTP_URL: "https://wifi.bcc.kz",
  GREEN_API: "https://green.bcc.kz/camunda",
  GREEN_API_TEST: "http://10.20.52.96:9001/camunda",
  REFERENCE_API: "https://green.bcc.kz/reference",
  PRODUCTION: "1",
};
