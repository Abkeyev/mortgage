import TableBody from '@material-ui/core/TableBody'
import React from 'react'
import { withStyles } from '@material-ui/core/styles'

const BccTableBody = withStyles({})((props: any) => <TableBody {...props} />)

export default BccTableBody
